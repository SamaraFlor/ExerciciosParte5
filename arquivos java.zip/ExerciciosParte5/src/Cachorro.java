
public class Cachorro extends Animal {

	
	public void som() {
		System.out.println("auau ");
	}
}
