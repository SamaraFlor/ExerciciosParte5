
public class SonsDaFazenda {

	public void sonsDaFazenda(Animal a) {
	               a.som();                     
}
	
	

}
