package P5E01;

public class Resto extends OperacoesMatematicas {

	public double calcular(double x, double y) {
		return x % y;
}

}