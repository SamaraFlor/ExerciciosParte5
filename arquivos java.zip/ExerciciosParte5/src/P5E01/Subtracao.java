package P5E01;

public class Subtracao extends OperacoesMatematicas {

	public double calcular(double x, double y) {
		return x - y;

	}

}
