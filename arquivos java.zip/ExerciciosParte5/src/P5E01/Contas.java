package P5E01;

public class Contas {

	public static void mostrarCalculo(OperacoesMatematicas operacao, double x, double y) {
		System.out.println("O resultado �: " + operacao.calcular(x, y));

	}
}