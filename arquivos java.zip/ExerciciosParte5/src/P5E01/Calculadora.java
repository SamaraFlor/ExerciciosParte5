package P5E01;

public class Calculadora {

	public static void main(String[] args) {
		
			
			 Contas.mostrarCalculo(new Soma(), 5, 5);
			 Contas.mostrarCalculo(new Multiplicacao(), 5, 5);
			 Contas.mostrarCalculo(new Resto(), 5, 5);
			 Contas.mostrarCalculo(new Divisao(), 5, 5);
			 Contas.mostrarCalculo(new Subtracao(), 5, 5);
			 

	}

}
