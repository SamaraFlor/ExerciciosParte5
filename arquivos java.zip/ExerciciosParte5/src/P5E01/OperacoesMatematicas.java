package P5E01;

public abstract class OperacoesMatematicas {

	
	
	public abstract double calcular(double x, double y);{
	}
}
