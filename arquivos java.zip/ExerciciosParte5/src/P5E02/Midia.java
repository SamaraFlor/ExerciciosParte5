package P5E02;

public class Midia {
	protected int codigo;
	protected double preco;
	protected String nome;

	public Midia() {
	}

	public Midia(int codigo, double preco, String nome) {
		super();
		this.codigo = codigo;
		this.preco = preco;
		this.nome = nome;
	}

	public String getTipo() {
		return this.nome;
	}

	public String getDetalhes() {
		return "musica 1,2 e 3 ";
	}

	public void printDados() {
	}

	public void inserirDados() {
	}

}
