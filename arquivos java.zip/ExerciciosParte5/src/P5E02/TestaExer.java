package P5E02;

public class TestaExer {

	public static void main(String[] args) {
		
		DVD dvd = new DVD();
		dvd.getTipo();
		CD cd = new CD();
		cd.getTipo();
		Midia midia = new Midia();
		midia.getTipo();
		System.out.println("nome das classes:    " + 
		                    midia.getTipo()+ " , " +  
				               cd.getTipo() +  "  e    "     
		                     + dvd.getTipo());

		
		System.out.println("nome das classes:    " + midia.getDetalhes()+ " , "  
		                                           + cd.getDetalhes() +  "  e    "   
				                                   + dvd.getDetalhes());

		
	
	}

}
