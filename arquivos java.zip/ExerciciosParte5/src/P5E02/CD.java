package P5E02;

public class CD extends Midia {
      protected int nMusicas;

	public CD() {
	}

	public CD(int nMusicas,int codigo, double preco, String nome) {
		this.nMusicas = nMusicas;
	}
     
	public  String getTipo() {
		return "CD";
	}
	
	public String getDetalhes() {
		return "musicas brasileiras, musica internacional";
	}
	
	public void setnMusicas(int m) {
	}

	public void inserirDados() {
	}

      
}
