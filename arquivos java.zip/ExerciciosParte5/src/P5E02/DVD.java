package P5E02;

public class DVD extends Midia {
   protected int nFaixas;

   	public DVD() {
	}

	public DVD(int nFaixas,int codigo, double preco, String nome) {
		this.nFaixas = nFaixas;
	}
	

	public  String getTipo() {
		return "DVD";
	}

	public String getDetalhes() {
		return "musicas de rock e forro";
	}

	public void setnFaixas(int f) {
	}

	public void inserirDados() {
	}

   
}
