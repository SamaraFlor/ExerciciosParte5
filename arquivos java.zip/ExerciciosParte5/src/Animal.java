

public abstract class Animal{
	protected int idade;
	protected double peso; 
	protected String esp�cie;
	private String especie;
	
	
	public Animal() {
		super();
	}


	public Animal(int idade, double peso, String esp�cie) {
		super();
		this.idade = idade;
		this.peso = peso;
		this.esp�cie = esp�cie;
	}



	public int getIdade() {
		return idade;
	}


	public void setIdade(int idade) {
		this.idade = idade;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public String getEspecie() {
		return esp�cie;
	}


	public void setEsp�cie(String especie) {
		this.especie = especie;
	}
	
	

	
	public abstract void som();
}