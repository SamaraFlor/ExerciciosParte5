
public class Gato extends Animal {

	
	public void som() {
		System.out.println("miau");
	}
}
