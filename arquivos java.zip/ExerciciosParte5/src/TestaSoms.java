
public class TestaSoms {

	public static void main(String[] args) {
		Cachorro rex = new Cachorro();
		rex.setPeso(9.00);
		rex.setIdade (3);
		rex.setEsp�cie("canina");
		
		Galinha pintadinha = new Galinha();
		pintadinha.setPeso(2.0);
		pintadinha.setIdade (1);
		pintadinha.setEsp�cie("galinha");
		
		Gato alfredo = new Gato();
		alfredo.setPeso(2.0);
		alfredo.setIdade (1);
		alfredo.setEsp�cie("gato");
		
		Vaca mimosa = new Vaca();
		alfredo.setPeso(40);
		alfredo.setIdade (3);
		alfredo.setEsp�cie("vaca");
		
		SonsDaFazenda s = new SonsDaFazenda();
	    s.sonsDaFazenda(rex);
	    s.sonsDaFazenda(pintadinha);
	    s.sonsDaFazenda(alfredo);
	    s.sonsDaFazenda(mimosa);
	
	    

	}
}
