
public class Galinha extends Animal {

	public void som() {
		System.out.println("cocorico");
	}

}
