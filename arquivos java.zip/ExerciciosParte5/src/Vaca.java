
public class Vaca extends Animal {

	public void som() {
		System.out.println("muuuuuu");
	}
}
